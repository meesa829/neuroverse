import { NextResponse } from 'next/server'

export async function GET() {
  const hasApiKey = !!process.env.ANTHROPIC_API_KEY

  return NextResponse.json({
    status: 'healthy',
    timestamp: new Date().toISOString(),
    ai: hasApiKey ? 'connected' : 'missing_api_key',
    version: '1.0.0',
  })
}
