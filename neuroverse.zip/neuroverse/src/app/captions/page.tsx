import { FileText } from 'lucide-react'
import { AITool } from '@/components/tools/AITool'

export const metadata = { title: 'AI Caption Generator — NeuroVerse' }

export default function CaptionsPage() {
  return (
    <AITool
      tool="caption"
      title="AI Caption Generator"
      description="Viral captions for Instagram, TikTok, YouTube and more — in seconds."
      icon={<FileText size={22} />}
      placeholder="E.g. Morning coffee routine, fitness transformation, travel photography in Bali..."
      accentColor="#8b5cf6"
    />
  )
}
