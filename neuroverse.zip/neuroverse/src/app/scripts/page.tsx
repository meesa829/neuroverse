import { Scroll } from 'lucide-react'
import { AITool } from '@/components/tools/AITool'

export const metadata = { title: 'AI Script Writer — NeuroVerse' }

export default function ScriptsPage() {
  return (
    <AITool
      tool="script"
      title="AI Script Writer"
      description="Complete video scripts with hooks, body, and CTAs. Ready to film."
      icon={<Scroll size={22} />}
      placeholder="E.g. 60-second TikTok about productivity hacks, YouTube video on crypto basics..."
      accentColor="#ff0080"
    />
  )
}
